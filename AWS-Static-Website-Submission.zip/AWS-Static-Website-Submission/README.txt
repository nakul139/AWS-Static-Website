AWS Static Website Deployment
=============================

Project:
Deploy Static Website on AWS

S3 Bucket:
my-641313198034-bucket

AWS Region:
us-east-1

S3 Website URL:
http://my-641313198034-bucket.s3-website-us-east-1.amazonaws.com/

CloudFront Distribution ID:
ERD306V4R6MIA

CloudFront Website URL:
https://d10qsry7h5dhlq.cloudfront.net/

Technologies:
- Amazon S3
- Amazon CloudFront
- HTML
- CSS
- JavaScript

Description:
This project deploys a static website using Amazon S3 static
website hosting and Amazon CloudFront as a content delivery
network (CDN).